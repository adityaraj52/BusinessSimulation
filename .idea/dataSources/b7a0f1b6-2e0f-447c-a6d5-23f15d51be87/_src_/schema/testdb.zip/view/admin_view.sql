CREATE VIEW `admin_view` AS
  SELECT
    `testdb`.`fgusers3`.`id_user`     AS `id_user`,
    `testdb`.`fgusers3`.`name`        AS `name`,
    `testdb`.`fgusers3`.`email`       AS `email`,
    `testdb`.`fgusers3`.`university`  AS `university`,
    `testdb`.`fgusers3`.`username`    AS `username`,
    `testdb`.`fgusers3`.`password`    AS `password`,
    `testdb`.`fgusers3`.`confirmcode` AS `confirmcode`,
    `testdb`.`fgusers3`.`role`        AS `role`,
    `testdb`.`fgusers3`.`deleted`     AS `deleted`
  FROM `testdb`.`fgusers3`
  WHERE ((`testdb`.`fgusers3`.`role` = 'Administrator') OR (`testdb`.`fgusers3`.`role` = 'Member') OR
         (`testdb`.`fgusers3`.`role` = 'Professor') OR (`testdb`.`fgusers3`.`role` = 'Guest'))